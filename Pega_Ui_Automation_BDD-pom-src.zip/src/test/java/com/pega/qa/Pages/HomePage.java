package com.pega.qa.Pages;

public class HomePage {

}
