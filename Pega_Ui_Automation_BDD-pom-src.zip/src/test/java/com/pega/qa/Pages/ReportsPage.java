package com.pega.qa.Pages;

import com.pega.qa.TestBase.TestBaseClass;

public class ReportsPage extends TestBaseClass{

}
