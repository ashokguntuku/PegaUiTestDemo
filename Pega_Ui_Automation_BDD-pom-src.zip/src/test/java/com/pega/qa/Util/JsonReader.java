package com.pega.qa.Util;

public class JsonReader {

	

}
